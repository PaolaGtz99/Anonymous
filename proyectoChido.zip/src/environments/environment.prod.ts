export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyCMmj_ERrW4reVM3iQV72mb_ezOgBYy-b0',
    authDomain: 'login-ng-a48bf.firebaseapp.com',
    databaseURL: 'https://login-ng-a48bf.firebaseio.com',
    projectId: 'login-ng-a48bf',
    storageBucket: 'login-ng-a48bf.appspot.com',
    messagingSenderId: '76902155661',
    appId: '1:76902155661:web:c5985b14342e0dbb4629c4'
  }
};
