export class ClauseModel{
    key:string;
    value:string;
    condition:string
}