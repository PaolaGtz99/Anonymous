export class UsuarioModel{
    email:string;
    nombre:string;
    tipoUsuario:string;
    uid:string;
}