export class UsuarioMaterialModel{
    idUsuario:string;
    idMateria:string;
    nota:number;
}