export class MateriaModel{
    nombre:string;
    uid:string;
}